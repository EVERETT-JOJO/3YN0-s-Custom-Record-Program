Instructions:

Put whatever .ogg files you would like to add, see Music Folder for example

Name in this format:

"Song Title" - "Artist"

ex. Row your boat - Steve.ogg

Optionally if you have a specific texture for each .ogg file then put that texture in the textures folder using the same format, with the exception of the
file extension which should be .png

ex. Row your boat - Steve.png

NOTE: If the titles don't match, or if no title is given, then the texture will select a random texture from the Textures/Default folder
You can also add/delete any textures in the Textures/Default Folder as you please


If you want to use your own custom resource pack, replace the "3yn0_custom_records_resourcepack" folder with whatever resource pack you'd like to use
Ensure the resource pack is not a .zip file. (This is useful if you have a specific resource pack for a server)

I recommend having a backup of your Textures, OGG files, datapack and resource  pack, just in case something goes wrong

When you run the program it will remove any of the Textures and Music files to ensure you do not duplicate them if you run the program twice

If it is successfuly ou should get a message in the program giving it a Title_ID, a Title, and a # ID

Once you have finished you can take the resource pack, and put it on your server/client %appdata%/.minecraft/resourcepacks and the datapack in the world file of your specific world
or server world/datapacks

To get the discs, a creeper must be shot by a skeleton and there will be a chance of it dropping



Config:
By default the paths are directed towards this directory, alternativley you can change them in the config file.



Commands:

Make sure you change #ID# with the ID of the record you'd like (Note: The title will not be the same, that will only happen if the creeper is killed by an arrow of a skeleton)

(Use for Vanilla)
/give @p music_disc_11{CustomModelData:#ID#,display:{Name:'[{"text":"Music Disc","italic":false}]',Lore:['[{"text":"Title","italic":false,"color":"dark_blue"}]']},HideFlags:32} 1
or
(Use for Paper)
/give @p music_disc_11 1 {CustomModelData:#ID#,display:{Name:'[{"text":"Music Disc","italic":false}]',Lore:['[{"text":"Title","italic":false,"color":"dark_blue"}]']},HideFlags:32}
